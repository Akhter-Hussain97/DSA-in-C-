#include<iostream>
using namespace std;
int main(){
	int i,pos,no;
	cout<<"enter the position and number"<<endl;
	cin>>pos>>no;
	int arr[100]={11,22,33,5,10};
	for(i=4; i>pos; i--)
		arr[i+1]=arr[i];
		arr[pos]=no;
		cout<<"Display New array"<<endl;
	for(i=0; i<6; i++)
	cout<<arr[i];
}