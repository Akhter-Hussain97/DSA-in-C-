//Write a program to search the position of largest element in array.
#include<iostream>
using namespace std;
int LargestElementPos(const int arr[], int size){
    if(size<=0){
        return -1;
    }

    int maxelement=arr[0];
    int position=0;

    for (int i=0; i<size; i++){
        if (arr[i]>=maxelement){
            maxelement=arr[i];
            position=i;
        }
    }

    return position;
}

int main(){
    const int size=5;
    int array[size];
    cout<<"enter five size of elements array:"<<size<<endl;
    for(int i=0; i<size; i++){
        cin>>array[i];
    }
    int position=LargestElementPos(array, size);

    if(position!=-1){
        cout <<"The largest element is at position:"<<position + 1<<endl;
    } else {
        cout<<"Invalid"<<endl;
    }
    return 0;
}
