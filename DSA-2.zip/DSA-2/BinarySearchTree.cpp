#include<iostream>
using namespace std;
struct Node{
	public:
	int data;
	Node *left, *right;
	Node(int val){
		data=val;
		left=right=NULL;
	}
};
	Node *InsertBST(Node *root, int val){
		if(root==NULL){
			return new Node(val);
		}
		else if(val<root->data){
			root->left=InsertBST(root->left,val);
		}
		else
		{
			root->right=InsertBST(root->right,val);
		}
		return root;
	}
	void Inorder(Node *root){
		if(root!=NULL){
		Inorder(root->left);
		cout<<root->data<<endl;
		Inorder(root->right);
	}
	}
int main(){
	Node *root=NULL;
   root=InsertBST(root,5);
	InsertBST(root,1);
	InsertBST(root,4);
	InsertBST(root,7);
	cout<<"Inorder Traversal of BST"<<endl;
	Inorder(root);
}