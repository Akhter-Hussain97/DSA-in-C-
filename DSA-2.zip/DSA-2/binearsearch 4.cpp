#include<iostream>
using namespace std;
int Binearsearch(int arr[], int key, int low, int high){
	if(low>high){
		return -1;
	}
	int mid=(low+high)/2;
	if(arr[mid]==key){
		return mid;
	}
	else if(arr[mid]>key){
		return Binearsearch(arr,key,low,mid-1);
	}
	else
	 return Binearsearch(arr,key,mid+1,high);
}
int main(){
	int size,key;
	cout<<"enter the size"<<endl;
	cin>>size;
	int low=0,high=size-1;
	int arr[size];
	cout<<"enter the search key"<<endl;
	cin>>key;
	cout<<"enter the array element"<<endl;
		for(int i=0; i<size; i++){
		cin>>arr[i];
	}
  int index=Binearsearch(arr,key,0,size-1);
	if(index!=-1){
		cout<<"index found at="<<index<<endl;
	}
}