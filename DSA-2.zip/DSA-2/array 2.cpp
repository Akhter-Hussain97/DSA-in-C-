#include<iostream>
using namespace std;
int main(){
	int i,maxno,minno;
	int arr[4]={83,37,89,100};
	for(int i=0; i<4; i++){
		cout<<"\a";
	}
	 maxno=arr[0];
	 minno=arr[0];
	for(i=0; i<4; i++)
	if(maxno<arr[i])
	   maxno=arr[i];
		cout<<maxno<<endl;			 maxno=arr[0];
	 minno=arr[0];
	for(i=0; i<4; i++)
	if(minno>arr[i])
	   minno=arr[i];
		cout<<minno<<endl;
	
}