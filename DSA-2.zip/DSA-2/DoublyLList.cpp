#include<iostream>
using namespace std;
class DoublyLList{
	struct Node{
		int data;
		Node *next;
		Node *prev;
	};
	public:
		Node *head;
		Node *tail;
		DoublyLList(){
			head=tail=NULL;
		}
		void InsertEnd(int data){
		Node *newNode=new Node(data);
		newNode->data=data;
		newNode->next=NULL;
		newNode->prev=NULL;
	  if(head==NULL){
	  	  tail=head=newNode;
	  }
	  else{
	  	Node *nodeptr;
	  	nodeptr->tail=newNode;
	  	newNode->prev=tail;
	  	tail=newNode;
	  }
}
};
int main(){
	DoublyLList list;
	
}