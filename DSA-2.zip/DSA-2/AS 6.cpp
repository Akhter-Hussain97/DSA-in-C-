//Writ a program to merge two lists.
#include<iostream>
#include<list>
using namespace std;
list<int> mergeLists(const list<int>& list1, const list<int>& list2){
    list<int> mergedList = list1;
    mergedList.insert(mergedList.end(), list2.begin(), list2.end());
    return mergedList;
}
void displayList(const list<int>& myList){
    for (int element:myList) {
    cout<<element<<" ";
    }
    cout<<endl;
}

int main(){
    list<int>list1={11, 342, 43};
    list<int>list2={14, 52, 906};
    list<int>mergedList=mergeLists(list1, list2);
    cout <<"Merged List:";
    displayList(mergedList);
    return 0;
}
