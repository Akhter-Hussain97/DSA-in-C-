//Write a program to count total number of capital letters in a string.
#include<iostream>
#include<cctype>
using namespace std;
int CapitalLetter(const string& str){
    int count=0;

    for(char ch:str){
        if(isupper(ch)){
            count++;
        }
    }
 return count;
}

int main(){
    string inputString;
    cout << "Enter a string: ";
    getline(cin, inputString);
    int capitalCount=CapitalLetter(inputString);
    cout<<"Total number of capital letters:"<<capitalCount<<endl;
    return 0;
}
