//Write a program to calculate total number of even values in an array.
#include <iostream>
using namespace std;
void CountEvenOdd(const int arr[],int size,int& evenCount,int& oddCount){
    evenCount=0;
    oddCount=0;

    for(int i=0; i<size; ++i) {
        if(arr[i]%2==0) {
            evenCount++;
        } else{
            oddCount++;
        }
    }
}

int main() {
    const int size=6;  
    int array[size];
cout <<"Enter size elements of the array:"<<size<<endl;
    for(int i=0; i<size; ++i){
        cin>>array[i];
    }
    int evenCount, oddCount;
    CountEvenOdd(array, size, evenCount, oddCount);
    cout<<"Total number of even numbers:"<<evenCount<<endl;
cout<<"Total number of odd numbers: "<<oddCount<<endl;
    return 0;
}
