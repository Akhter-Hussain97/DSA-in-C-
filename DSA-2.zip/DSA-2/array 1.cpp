#include<iostream>
using namespace std;
int main(){
/*	int a[5];
	cout<<"enter the five array"<<endl;
	for(int i=0;i<5;i++){
		cin>>a[i];
	}
	for(int i=0;i<=5;i++){
		cout<<a[i];
	}
	
}*/
int a[5]={14,35,90,25,12};
	cout<<"enter the five array"<<endl;
	for(int i=0;i<5;i++){
		cout<<a[i];
	}
	
    
 }