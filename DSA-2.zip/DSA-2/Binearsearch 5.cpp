#include<iostream>
using namespace std;
int arr[10],size,x;
int Binarysearch(int low,int high){
	while(low<=high){
		int mid=low+high/2;
		if(arr[mid]==x){
			return mid;
		}
		else if(arr[mid]>x){
			high =mid-1;
			return high;
		}
		else
		low= mid+1;
		return low;
	}
	return -1;
}
int main(){
	cout<<"enter the array size"<<endl;
	cin>>size;
	cout<<"enter the all array element"<<endl;
	for(int i=0; i<size; i++){
		cin>>arr[i];
	}
	cout<<"the search array is "<<endl;
	cin>>x;
  int result=Binarysearch(0,size-1);
  if(result==-1){
  	cout<<"not found"<<endl;
  }
  else
  cout<<"no found"<<result<<endl;
}