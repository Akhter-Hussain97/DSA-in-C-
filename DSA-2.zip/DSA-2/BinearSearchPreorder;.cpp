#include<iostream>
using namespace std;
class PreorderBinearSearch{
	struct Node{
		int data;
		Node *root;
		Node *left;
		Node *right;
	};
	public:
		PreorderBinearSearch(){
	  Node *root=NULL;
}
   void Create(int n){
   	  root->left;
   	  root->right;
   	  if(root==NULL){
   	  	cout<<"Empty list";
		 }
	else{
	  cout<<root->data;	
	}
   	    
   };
int main(){
	PreorderBinearSearch p;
	p.Create(5);
	p.Create(4);
	p.Create(8);	
}