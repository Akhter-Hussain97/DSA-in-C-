/* Write a program to input and push 10 values into stack.Pop the values and display only even values on the screen.*/
#include<iostream>
#include<stack>
using namespace std;
int main(){
    const int stackSize=10;
    stack<int> myStack;
    cout<<"Enter values to push into the stack:"<<stackSize<<endl;
    for(int i=0; i<stackSize; i++){
        int value;
        cin>>value;
        myStack.push(value);
    }
    cout<<"Even values popped from the stack:"<<endl;
    while(!myStack.empty()){
        int PopValue=myStack.top();
        myStack.pop();

        if(PopValue%2==0){
            cout<<PopValue<<endl;
        }
    }

    return 0;
}
