#include<iostream>
using namespace std;
int arr[10]={13,14,32,44,56,67,78,88,98,99},x,n,i;
int binearsearch(int low,int high,int x){
	int mid=low+high/2;
	while(low<=high){
		if(arr[mid]==x){
			return mid;
		}
		else if(arr[mid]<x){
			low=mid+1;
			return low;
		}
		else if(arr[mid]>x){
				high=mid-1;
				return high;
		}
	}
	return -1;
}
int main(){
	cin>>n;
	for(int i=0; i<n;i++){
	cout<<arr[i]<<endl;
}
   cin>>x;
   int result=binearsearch(0,n-1,x);
   if(result==-1){
   	cout<<"not found"<<endl;
   }
   else
   cout<<"number found"<<result<<endl;
}
