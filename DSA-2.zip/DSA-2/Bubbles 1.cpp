#include<iostream>
using namespace std;
int main(){
	int arr[]={45,67,12,43,95,10};

		for(int i=0; i<6; i++){
			cout<<arr[i]<<endl;
		}
	for(int i=0; i<6-1; i++)
	for(int j=0; j<6-i-1; j++){
		if(arr[j]>arr[j+1]){
			int temp;
			temp=arr[j];
			arr[j]=arr[j+1];
			arr[j+1]=temp;
		}
	}
	cout<<"after sorting"<<endl;
	for(int i=0; i<6; i++){
		cout<<arr[i]<<endl;
	}
	
}