#include<iostream>
using namespace std;
int main(){
   const int SIZE=5;
   int array[SIZE];
   for(int i=0; i<SIZE; i++){
   	 cin>>array[i];
   }
     for(int j=0; j<SIZE; j++){
   	 float total=0;
   	 total+=array[j];
   	 double average;
   	 average=total/SIZE;
   	 cout<<"average="<<average<<endl;
   }
}