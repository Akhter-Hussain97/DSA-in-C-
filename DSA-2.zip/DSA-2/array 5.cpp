#include<iostream>
using namespace std;
int main(){
	int k=-1;
	int num,z,a[5]={13,23,89,4,9};
	cout<<"enter the no in search "<<endl;
	cin>>num;
	for(int i=0; i<5; i++)
		if(num==a[i]){
			k=0;
			 z=i;
			break;
		}
		if(k==0)
			cout<<"Number Found"<<z<<endl;
			
		else
		cout<<"Number Not Found"<<endl;
}