#include<iostream>
using namespace std;
struct Node{
	int data;
	Node *next;
	Node *prev;
};
	class PriorityQueue{
		private:
		Node *head,*tail;
		int front;
		int rear;
		public:
			PriorityQueue(){
				head=tail=NULL;
			}
			void IsEmpty(){
				if(front==-1 && rear==-1){
				cout<<"List Empty";
			}
			else
			{
		      int x;
		      [++front]=x;
			}
			}
			void Create(){
		Node *newnode=new Node();
		cout<<"enter data"<<endl;
		cin>>newnode->data;
		newnode->next=NULL;
		newnode->prev=NULL;
		if(head==NULL){
			head=tail=newnode;
		}
		else{
		tail->next=newnode;
		newnode->prev=tail;
		tail=newnode;
	}
	}  
	void insertAtBeg(){
			Node *newnode=new Node;
		cout<<"enter data"<<endl;
		cin>>newnode->data;
		newnode->next=NULL;
		newnode->prev=NULL;
		if(head==NULL){
			head=tail=newnode;
		}
		else{
		head->prev=newnode;
		newnode->prev=head;
		head=newnode;
	}
	}
};
int main(){
	 PriorityQueue obj1;
	 obj1.Create(5);
	 obj1.Create(8);
}