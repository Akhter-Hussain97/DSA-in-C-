#include<iostream>
using namespace std;
class Node{
	public:
   int data;
   Node *left, *right;
   Node(int val){
   	   data=val;
   	   left=right=NULL;
   }
};
   class BST{
   	public:
 	  Node *Insertbst(Node *root,int val){
 	  	if(root==NULL){
 	  	return new Node(val);
	   }
	   else if(val<root->data){
        root->left=Insertbst(root->left,val);
	   }
	   else{
	   	root->right=Insertbst(root->right,val);
	   }
	   return root;
}
};
 int main(){
 	Node *root=NULL;
 	root=Insertbst(root,5);
 	Insertbst(root,1);
 	Insertbst(root,6);
 	return 0;
 }