#include<iostream>
using namespace std;
struct Node{
	public:
		int data;
		Node *left, *right;
	Node(int val){
		data=val;
		left=right=NULL;
	}
};
 Node *InsertBST(Node *root, int val){
 	if(root==NULL){
 		return new Node(val);
	 }
	 else if(val<root->data){
	 	root->left=InsertBST(root->left,val);
	 }
	 else{
	 	root->right=InsertBST(root->right,val);
	 }
	 return root;
 }
 void PostOrder(Node *root){
	if(root!=NULL){
		PostOrder(root->left);
		PostOrder(root->right);
		cout<<root->data<<endl;
	}
}
 int main(){
 	Node *root=NULL;
 	root=InsertBST(root,4);
 	InsertBST(root,6);
 	InsertBST(root,9);
 	PostOrder(root);
 }