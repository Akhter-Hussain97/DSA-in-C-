/*PROGRAM #5: Write a program to convert an infix expression to prefix using 
stacks.*/
#include <iostream>
#include <stack>
#include <algorithm>
bool isOperator(char c) {
 return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}
int getPrecedence(char op) {
 if (op == '^')
 return 3;
 else if (op == '*' || op == '/')
 return 2;
 else if (op == '+' || op == '-')
 return 1;
 else
 return -1; // For '(' and ')'
}
std::string infixToPrefix(const std::string &infixExpression) {
 std::stack<char> operatorStack;
 std::string prefixExpression;
 for (int i = infixExpression.length() - 1; i >= 0; --i) {
 char currentChar = infixExpression[i];
 if (isalnum(currentChar)) {
 prefixExpression += currentChar;
 } else if (currentChar == ')') {
 operatorStack.push(currentChar);
 } else if (currentChar == '(') {
 while (!operatorStack.empty() && operatorStack.top() != ')') {
 prefixExpression += operatorStack.top();
 operatorStack.pop();
 }
 operatorStack.pop(); // Pop '('
 } else if (isOperator(currentChar)) {
 while (!operatorStack.empty() && getPrecedence(currentChar) < 
getPrecedence(operatorStack.top())) {
 prefixExpression += operatorStack.top();
 operatorStack.pop();
 }
 operatorStack.push(currentChar);
 }
 }
 while (!operatorStack.empty()) {
 prefixExpression += operatorStack.top();
 operatorStack.pop();
 }
 std::reverse(prefixExpression.begin(), prefixExpression.end());
 return prefixExpression;
}
int main() {
 std::string infixExpression = "(3+2)^4-5";
 std::string prefixExpression = infixToPrefix(infixExpression);
 std::cout << "Prefix expression: " << prefixExpression << std::endl;
 return 0;
}