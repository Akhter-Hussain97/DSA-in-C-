#include<iostream>
using namespace std;
	class Node{
		public:
		int data;
		Node *left, *right;
		Node(int val){
			data=val;
			left=right=NULL;
		}
	};
class Inorder{
	public:
		void INorder(Node *root){
		   if(root==NULL){
		   	return;
		   }
		   else
		   {
		   	INorder(root->left);
		   	cout<<root->data;
			INorder(root->right);
		   }
		}
};
int main(){
	Inorder tree;
	Node *root=new Node(1);
	root->left=new Node(2);
	root->right=new Node(3);
    cout<<"Inorder Traversal"<<endl;
    tree.INorder(root);
}