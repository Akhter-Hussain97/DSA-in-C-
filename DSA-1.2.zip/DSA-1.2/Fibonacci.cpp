#include<iostream>
using namespace std;
void Fibonacci(int a,int b,int n){
	if(n==0){
		return;
	}
	int c=a+b;
	cout<<c<<endl;
	Fibonacci(b,c,n-1);
}
int main(){
	int n,a=0,b=1;
	cout<<a<<b<<endl;
	cout<<"enter the number"<<endl;
	cin>>n;
	Fibonacci(a,b,n-2);
}