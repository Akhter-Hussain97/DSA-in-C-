#include<iostream>
using namespace std;
int main(){
	int arr[10]={1,4,2,6,7,8,9,3},pos,x;
	for(int i=0; i<9; i++){
		cout<<arr[i]<<endl;
	}
	cout<<"positon search"<<endl;
	cin>>pos;
	cout<<"pos value"<<endl;
	cin>>x;
	for(int i=8; i>pos-1; i--){
		arr[pos-1]=arr[i];
	}
	arr[pos-1]=x;
		for(int i=0; i<9; i++){
		cout<<arr[i]<<endl;
	}
}