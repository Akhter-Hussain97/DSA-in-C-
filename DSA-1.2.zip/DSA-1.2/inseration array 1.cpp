#include<iostream>
using namespace std;
int main(){
	int arr[10],n,x;
	cout<<"enter the no of array"<<endl;
	cin>>n;
	cout<<"enter the array element "<<endl;
	for(int i=0; i<n; i++){
		cin>>arr[i];
	}
	cout<<"enter the array at the beginning"<<endl;
	cin>>x;
	for(int i=n; i>0; i--){
		arr[i]=arr[i-1];
	}
	arr[0]=x;
	n++;
   for(int i=0; i<n; i++){
   	cout<<arr[i]<<endl;
   }
   return 0;
}