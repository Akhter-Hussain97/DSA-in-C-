/*PROGRAM #2: Write a C++ program to implement a queue using an array with 
enqueue and dequeue operations.*/
#include <iostream>
const int MAX_SIZE = 5;
class Queue {
private:
 int front, rear;
 int array[MAX_SIZE];
public:
 Queue() : front(-1), rear(-1) {}
 // Function to check if the queue is empty
 bool isEmpty() {
 return front == -1 && rear == -1;
 }
 // Function to check if the queue is full
 bool isFull() {
 return (rear + 1) % MAX_SIZE == front;
 }
 // Function to enqueue (insert) an element into the queue
 void enqueue(int value) {
 if (isFull()) {
 std::cerr << "Error: Queue is full" << std::endl;
 return;
 }
 if (isEmpty()) {
 front = rear = 0;
 } else {
 rear = (rear + 1) % MAX_SIZE;
 }
 array[rear] = value;
 std::cout << "Enqueued " << value << " into the queue." << std::endl;
 }
 // Function to dequeue (remove) an element from the queue
 int dequeue() {
 if (isEmpty()) {
 std::cerr << "Error: Queue is empty" << std::endl;
 return -1; // Assuming -1 as an error value for simplicity
 }
 int dequeuedValue = array[front];
 if (front == rear) {
 // If there was only one element in the queue
 front = rear = -1;
 } else {
 front = (front + 1) % MAX_SIZE;
 }
 std::cout << "Dequeued " << dequeuedValue << " from the queue." << std::endl;
 return dequeuedValue;
 }
};
int main() {
 Queue queue;
 // Enqueue some elements
 queue.enqueue(10);
 queue.enqueue(20);
 queue.enqueue(30);
 // Dequeue elements
 int dequeuedValue1 = queue.dequeue();
 int dequeuedValue2 = queue.dequeue();
 // Enqueue more elements
 queue.enqueue(40);
 queue.enqueue(50);
 // Dequeue elements
 int dequeuedValue3 = queue.dequeue();
 int dequeuedValue4 = queue.dequeue();
 return 0;
}
