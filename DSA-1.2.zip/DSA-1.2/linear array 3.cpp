#include<iostream>
using namespace std;
int main(){
	int arr[10],x,SIZE,i;
	cout<<"enter the size"<<endl;
	cin>>SIZE;
	cout<<"enter the array element"<<endl;
	for(i=0; i<SIZE; i++){
	cin>>arr[i];
}
 cout<<"enter the array value"<<endl;
      cin>>x;
   for(i=0; i<SIZE; i++){
   	if(arr[i]==x){
   		cout<<"the index of array is"<<i<<"index value is "<<arr[i]<<endl;
   		break;
	   }
	if(i==x){
   	cout<<"number not found "<<endl;
   }
   }
}