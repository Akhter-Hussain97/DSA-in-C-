#include<iostream>
using namespace std;
int main(){
	int arr[10],n,x,pos;
	cout<<"enter the size of array"<<endl;
	cin>>n;
	cout<<"enter the array element "<<endl;
	for(int i=0; i<n; i++){
		cin>>arr[i];
	}
	cout<<"enter the array  insert at the specific location"<<endl;
	cin>>pos;
	cout<<"enter the position value "<<endl;
	cin>>x;
	for(int i=n-1; i>=pos-1; i--){
		arr[i+1]=arr[i];
	}
	arr[pos-1]=x;
	n++;
   for(int i=0; i<n; i++){
   	cout<<arr[i]<<endl;
   }
   return 0;
}