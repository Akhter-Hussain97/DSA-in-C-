#include<iostream>
using namespace std;
int main(){
	int arr[10],n,x,i;
	cout<<"enter the size of array"<<endl;
	cin>>n;
	cout<<"enter the array element "<<endl;
	for(i=0; i<n; i++){
		cin>>arr[i];
	}
	cout<<"enter the array  insert at the end"<<endl;
	cin>>x;
	arr[i]=x;
	n++;
   for(i=0; i<n; i++){
   	cout<<arr[i]<<endl;
   }
   return 0;
}