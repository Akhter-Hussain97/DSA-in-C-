/*PROGRAM #4: Write a program to evaluate Prefix expressions using stacks.*/
#include <iostream>
#include <stack>
#include <cmath>
bool isOperator(char c) {
 return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}
double evaluatePrefixExpression(const std::string &expression) {
 std::stack<double> operandStack;
 for (int i = expression.length() - 1; i >= 0; --i) {
 if (isdigit(expression[i])) {
 operandStack.push(expression[i] - '0'); // Convert char to int
 } else if (isOperator(expression[i])) {
 double operand1 = operandStack.top();
 operandStack.pop();
 double operand2 = operandStack.top();
 operandStack.pop();
 switch (expression[i]) {
 case '+':
 operandStack.push(operand1 + operand2);
 break;
 case '-':
 operandStack.push(operand1 - operand2);
 break;
 case '*':
 operandStack.push(operand1 * operand2);
 break;
 case '/':
 operandStack.push(operand1 / operand2);
 break;
 case '^':
 operandStack.push(pow(operand1, operand2));
 break;
 }
 }
 }
 return operandStack.top();
}
int main() {
 std::string prefixExpression = "*+32^45";
 double result = evaluatePrefixExpression(prefixExpression);
 std::cout << "Result of the prefix expression: " << result << std::endl;
 return 0;
}
