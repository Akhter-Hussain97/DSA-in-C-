/*PROGRAM #1: Write a program to input and push 10 values into a stack. Pop the 
values from the stack and print only even values on the screen.*/
#include <iostream>
const int MAX_SIZE = 10;
class Stack {
private:
 int top;
 int array[MAX_SIZE];
public:
 Stack() : top(-1) {}
 void push(int value) {
 if (top < MAX_SIZE - 1) {
 array[++top] = value;
 } else {
 std::cerr << "Error: Stack is full" << std::endl;
 }
 }
 int pop() {
 if (top >= 0) {
 return array[top--];
 } else {
 std::cerr << "Error: Stack is empty" << std::endl;
 return -1; // Error value for an empty stack
 }
 }
 bool isEmpty() {
 return top == -1;
 }
};
int main() {
 Stack stack;
 // Input and push 10 values onto the stack
 for (int i = 0; i < 10; ++i) {
 int value;
 std::cout << "Enter value #" << i + 1 << ": ";
 std::cin >> value;
 stack.push(value);
 }
 std::cout << "Even values popped from the stack:" << std::endl;
 // Pop values from the stack and print even values
 while (!stack.isEmpty()) {
 int poppedValue = stack.pop();
 if (poppedValue % 2 == 0) {
 std::cout << poppedValue << std::endl;
 }
 }
 return 0;
}