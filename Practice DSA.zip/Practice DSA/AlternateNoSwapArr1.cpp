#include<iostream>
using namespace std;
void SwapAlternate(int arr[], int size){
	for(int i=0; i<size; i+=2){
		if(i+1<size){
		int temp;
		temp =arr[i+1];
		arr[i+1]=arr[i];
		arr[i]=temp;
	}
}
}
int main(){
	int arr[6]={1,2,3,4,5,6};
	cout<<"Before Swaping "<<endl;
	for(int i=0; i<=5; i++){
		cout<<arr[i]<<endl;
	}
	cout<<"After Swaping "<<endl;
	SwapAlternate(arr, 6);
		for(int i=0; i<=5; i++){
		cout<<arr[i]<<endl;
	}
	return 0;
}