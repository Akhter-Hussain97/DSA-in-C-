#include<iostream>
using namespace std;
int main(){
	int n=5;
	int arr[]={1,2,3,4,5};
	int  end;
	int start=0;
	for(start=0; start<n; start++){
		for(end=start; end<n; end++){
			for(int i=start; i<=end; i++){
				cout<<arr[i];
			}
			cout<<" ";
		}
		cout<<endl;
	}
}