#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	int bit=n&1;
	cout<<bit<<endl;
	n=n>>1;
	cout<<n;
	
}