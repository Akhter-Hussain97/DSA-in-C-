#include <iostream>
using namespace std;

// Base class
class Animal {
    protected:
      int age;
   public:
      Animal(int a):age(a){} //default constructor
     virtual void Eat(){
          cout<<"Animal eats food"<<endl;
      }
     virtual int get_Age(){
          return age;
      }
};

// Derived class
class Dog: public Animal{
   public:
      Dog(int age=0) :Animal(age){}
        void Eat(){
          cout<<"Dog eats meats"<<endl;
      } //declaring and initializing derived class constructor 
      int get_Age(){
        return age;
      }
};
class Cat: public Animal{
   public:
      Cat(int age=0) :Animal(age){}
        void Eat(){
          cout<<"Cat eats meats"<<endl;
      } //declaring and initializing derived class constructor 
      int get_Age(){
        return age;
      }
};

int main(void) {
   Animal *s;
   Dog sq(5); //making object of child class Sqaure
   Cat rec(4); //making object of child class Rectangle
   
   s = &sq;
   cout<<s->get_Age();
   s->Eat();
   s= &rec;
   cout<<s->get_Age();
   s->Eat();
   return 0;}