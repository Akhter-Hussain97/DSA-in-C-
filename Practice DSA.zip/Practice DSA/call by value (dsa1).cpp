#include<iostream>
using namespace std;
int sum( int a, int b){
	a=a+2;
	b=b+3;
	return a+b;
}
int main(){
	int a=3, b=2;	cout<<sum(a,b);
	cout<<a<<""<<b<<endl;
}