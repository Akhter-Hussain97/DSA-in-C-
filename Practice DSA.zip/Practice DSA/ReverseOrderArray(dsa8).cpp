#include<iostream>
using namespace std;
int ReverseArr(int arr[],int size){
	int start=0;
	int end=size-1;
	while(start<end){
		swap(arr[start],arr[end]);
		start++;
		end--;
	}
	return -1;
}
int main(){
	int arr[6];
	cout<<"Enter the array the element"<<endl;
	for(int i=0; i<=5; i++){
		cin>>arr[i];
	}
	cout<<"Before Execution"<<endl;
	for(int i=0; i<=5; i++){
		cout<<arr[i]<<endl;
	}
	 ReverseArr(arr, 6);
	 	cout<<"After Execution"<<endl;
	for(int i=0; i<=5; i++){
		cout<<arr[i]<<endl;
	}
}