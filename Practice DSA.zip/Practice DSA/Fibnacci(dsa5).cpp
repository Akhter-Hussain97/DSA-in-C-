#include<iostream>
using namespace std;
int fib(int a, int b, int n){
	if(n==0){
		return 0;
	}
	int c=a+b;
	cout<<c<<endl;
	fib(b,c,n-1);
}
int main(){
	int a=0; 
	int b=1;
	int n=7;
	cout<<a<<""<<b<<endl;
	fib(a,b,n-2);
}