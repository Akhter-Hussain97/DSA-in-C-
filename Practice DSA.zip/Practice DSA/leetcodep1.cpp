#include<iostream>
using namespace std;
int main(){
	int arr[4]={1,3,4,5};
	int sum=0;
	int target=9;
	for(int i=0; i<4; i++){
		sum+=arr[i];
		if(sum==target){
		  cout<<sum<<endl;
		}
	}
}