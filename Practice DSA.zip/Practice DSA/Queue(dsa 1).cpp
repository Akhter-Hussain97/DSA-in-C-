#include<iostream>
#include<deque>
using namespace std;
int main(){
	deque<int> queue;
	queue.push_back(1);
	queue.push_back(2);
	queue.push_back(3);
	 cout<<queue.front()<<endl;
	 queue.pop_front();
	 cout<<queue.front()<<endl;
	 queue.pop_front();
	 cout<<queue.front()<<endl;
	 if(queue.empty()){
	  cout<<" Queue is Empty "<<endl;
	 }
	 else{
	   cout<<"Queue is Not Empty"<<endl;
	 }
	 return 0;
}