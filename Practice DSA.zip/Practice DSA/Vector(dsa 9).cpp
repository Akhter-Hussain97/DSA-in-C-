#include<iostream>
#include<vector>
using namespace std;
int main(){
	vector<int> vec;
//	vector<char> ch={'a', 'b','c'};
	//cout<<vec[0];
/*	for(char val: ch){
		cout<<val<<endl;
	}*/
  vec.push_back(12);
  vec.push_back(14);
  vec.push_back(18);
  for(int val: vec){
		cout<<val<<endl;
	}
  cout<<vec.size()<<endl;
  cout<<vec.capacity()<<endl;
}