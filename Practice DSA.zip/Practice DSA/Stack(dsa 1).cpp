#include<iostream>
#include<stack>
using namespace std;
int main(){
	stack<int> stack;
	stack.push(1);
	stack.push(2);
	stack.push(3);
	 cout<<stack.top()<<endl;
	 stack.pop();
	 cout<<stack.top()<<endl;
	 stack.pop();
	 cout<<stack.top()<<endl;
	 if(stack.empty()){
	  cout<<" Stack is Empty "<<endl;
	 }
	 else{
	   cout<<"Stack is Not Empty"<<endl;
	 }
	 return 0;
}