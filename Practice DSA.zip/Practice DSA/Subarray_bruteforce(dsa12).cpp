#include<iostream>
using namespace std;
int main(){
	int n=7;
	int arr[]={3,-4,5,4,-1,7,-8};
	int  end;
	int start=0;
	int maxSum=INT_MIN;
	for(start=0; start<n; start++){
		int currentSum=0;
		for(end=start; end<n; end++){
		   currentSum+=arr[end];
		   maxSum=max(currentSum,maxSum);
		}
	}
	cout<<maxSum;
}