#include<iostream>
using namespace std;
int sumprodArr(int arr[],int size){
	int sum=0;
	int prod=1;
	 for(int i=0; i<size; i++){
	 	sum+=arr[i];
	 }
	 return sum;
	  for(int i=0; i<size; i++){
	 	prod*=arr[i];
	 }
	 return prod;
}
int main(){
	int arr[5]={4,2,8,4,3};
	cout<<sumprodArr(arr,5)<<endl;
}