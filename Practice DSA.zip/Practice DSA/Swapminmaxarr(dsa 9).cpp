#include<iostream>
using namespace std;
int MaxMinArr(int arr[], int size){
	for(int i=0; i<size; i++){
		swap(max(i),min(i));
	}
	return ;
	
}
int main(){
	int arr[4]={3,2,1,7};
	cout<<MaxMinArr(arr,4)<<endl;
}