#include<iostream>
using namespace std;
int main(){
	int a=5;
	int b=6;
	cout<<"a and ="<<(a&b)<<endl;
	cout<<"a OR b"<<(a|b)<<endl;
	cout<<"a XOR b"<<(a^b)<<endl;
	cout<<"a NOT"<<~a<<endl;
	cout<<"Left Shift Operator"<<(5<<1)<<endl;
	cout<<"Left Shift Operator of 5 ="<<(5<<2)<<endl;
	cout<<"Left Shift Operator of 5 and ="<<(5<<3)<<endl;
	cout<<"Right Shift Operator of 5="<<(5>>1)<<endl;
	cout<<"Right Shift Operator of 5 of 2 ="<<(5>>2)<<endl;
	cout<<"Right Shift Operator of 15 ="<<(15>>1)<<endl;
}