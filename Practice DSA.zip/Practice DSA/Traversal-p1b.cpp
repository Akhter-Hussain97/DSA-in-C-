#include<iostream>
using namespace std;
 /*int traversal(int n, int arr[]){
 	  for(int i=0; i<n; i++){
 	  	cout<<arr[i]<<endl;
	   }
 }*/
 int inserationArray(int n, int arr[], int pos){
 	for(int i=0; i<n; i++){
 		if(i==pos){
 			arr[i]=arr[i+1];
 			int temp=arr[i];
 			return temp;
		 }
		 cout<<arr[i]<<endl;
	 }
 }
int main(){
	int arr[5]={10,20,40,50};
	int n=5;
	int pos=2;
	inserationArray(5,arr,2);
}