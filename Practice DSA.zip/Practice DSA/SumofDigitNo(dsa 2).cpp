#include<iostream>
using namespace std;
int SumofDigit(int n){
	int digitSum=0;
	while(n>0){
	 int lastdigit=n%10;
		n=n/10;
	   digitSum+=lastdigit;
	}
	return digitSum;
}
int main(){
	int n;
	cout<<"enter the no"<<endl;
	cin>>n;
	cout<<SumofDigit(n);
}