	int ans=0;
	for(int val:num){
		ans=ans^val;
	}
	return ans;	int ans=0;
	for(int val:num){
		ans=ans^val;
	}
	return ans;
