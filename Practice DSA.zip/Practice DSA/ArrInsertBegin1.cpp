#include<iostream>
#include<vector>
using namespace std;
int insertAtBegin(int arr, int element){
   for(int i=0; i<3; i++){
   	   cout<<arr[i]<<" ";
   }
   arr.insert(arr.begin(), element);
     for(int i=0; i<3; i++){
   	   cout<<arr[i]<<" ";
   }
}
int main(){
	vector<int> arr={20,30,40};
	int element=10;
	insertAtBegin(arr,10);
}