#include<iostream>
using namespace std;
int DecimalToBinary(int decNum){
	int pow=1 ; int ans=0;
	while(decNum>0){
		int rem=decNum%2;
		decNum=decNum/2;
		ans+=(pow*rem);
		pow=pow*10;
	}
	return ans;
}
int BinaryToDecimal(int BinNum){
	int pow=1 ; int ans=0;
	while(BinNum>0){
		int rem=BinNum%10;
		BinNum=BinNum/10;
		ans+=(pow*rem);
		pow=pow*2;
	}
	return ans;
}
int main(){
	int decNum, BinNum;
	cout<<"Enter the Decimal Number"<<endl;
	cin>>decNum;
	cout<<"Enter the Binary Number"<<endl;
	cin>>BinNum;
	cout<<"Convert Decimal to Binary Number "<<endl;
    cout<<DecimalToBinary(decNum)<<endl;
    	cout<<"Convert Binary to Decimal Number "<<endl;
	cout<<BinaryToDecimal(BinNum)<<endl;
}