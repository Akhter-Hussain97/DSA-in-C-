#include<iostream>
using namespace std;
int main(){
	int arr[10],size,temp;
	cout<<"enter the array size"<<endl;
	cin>>size;
	cout<<"enter the array element "<<endl;
	for(int i=0; i<size; i++){
		cin>>arr[i];
	}
	for(int i=0; i<size; i++){
		for(int j=i+1; j<size; j++){
			if(arr[i]>arr[j]){
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	cout<<"the sorting array is "<<endl;
	for(int i=0; i<size; i++){
		cout<<arr[i]<<endl;
	}
}