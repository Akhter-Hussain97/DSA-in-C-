#include<iostream>
using namespace std;
class Node {
public:
    int data;
    int priority;
    Node* next;
    Node* prev;

    Node(int d, int p): data(d), priority(p), next(nullptr), prev(nullptr){}
};

class PriorityQueue{
private:
    Node* front;

public:
    PriorityQueue() : front(nullptr) {}

    void enqueue(int data, int priority) {
        Node* newNode = new Node(data, priority);

        if (front == nullptr || priority < front->priority) {
            newNode->next = front;
            if (front != nullptr) {
                front->prev = newNode;
            }
            front = newNode;
        } else {
            Node* temp = front;
            while (temp->next != nullptr && temp->next->priority <= priority) {
                temp = temp->next;
            }

            newNode->next = temp->next;
            if (temp->next != nullptr) {
                temp->next->prev = newNode;
            }

            temp->next = newNode;
            newNode->prev = temp;
        }
    }

    void dequeue() {
        if (front == nullptr) {
            std::cout << "Queue is empty. Cannot dequeue.\n";
            return;
        }

        Node* temp = front;
        front = front->next;

        if (front != nullptr) {
            front->prev = nullptr;
        }

        delete temp;
    }

    int frontData() const {
        return (front != nullptr) ? front->data : -1; 
    }

    bool isEmpty() const {
        return (front == nullptr);
    }

    void printQueue() const {
        Node* temp = front;
        while (temp != nullptr) {
            std::cout << temp->data << " (Priority: " << temp->priority << ") ";
            temp = temp->next;
        }
        std::cout << "\n";
    }

    ~PriorityQueue() {
        while (front != nullptr) {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
    }
};

int main() {
    PriorityQueue pq;

    pq.enqueue(5, 2);
    pq.enqueue(10, 1);
    pq.enqueue(7, 3);

    cout << "Priority Queue: ";
    pq.printQueue();

    cout<<"Front of the queue: "<<pq.frontData() << "\n";

    pq.dequeue();

    cout<<"Priority Queue after dequeue: ";
    pq.printQueue();

}
