#include<iostream>
using namespace std;
int power(int x, int n){
		 if(n==0){
		return 1;
	}
	if(x==0){
		return 0;
	}
	else
	{
	return x*power(n,n-1);
}
}
int main(){
	int x,n;
	cout<<"enter the base"<<endl;
	cin>>x;
	cout<<"enter the power"<<endl;
	cin>>n;
	cout<<power(x,n)<<endl;
}