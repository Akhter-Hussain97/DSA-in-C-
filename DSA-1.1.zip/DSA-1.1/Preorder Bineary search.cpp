#include<iostream>
#include<stack>
using namespace std;
struct TreeNode{
    int data;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int value) : data(value), left(nullptr),right(nullptr){
	}
};

TreeNode* insert(TreeNode* root, int value){
    if(root == nullptr){
        return new TreeNode(value);
    }

    if(value<root->data){
        root->left=insert(root->left, value);
    } else{
        root->right=insert(root->right, value);
    }

    return root;
}
void preorderTraversal(TreeNode* root){
    if(root==nullptr){
        return;
    }

    stack<TreeNode*>nodeStack;
    nodeStack.push(root);

    while(!nodeStack.empty()){
        TreeNode* current=nodeStack.top();
        nodeStack.pop();

        cout<<current->data<< " ";

        if(current->right !=nullptr){
            nodeStack.push(current->right);
        }

        if (current->left != nullptr){
            nodeStack.push(current->left);
        }
    }
}

int main(){
    TreeNode* root=nullptr;
    int values[]={10, 5, 15, 3, 7, 12, 18};

    for(int value : values){
        root=insert(root, value);
    }

    cout<<"Preorder Traversal";
    preorderTraversal(root);
}
