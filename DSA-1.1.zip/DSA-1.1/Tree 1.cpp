#include<iostream>
using namespace std;
class Node{
	private:
		int data;
		Node *left, *right;
	public:
		Node(int val){
			int data=val;
			left=right=NULL;
		}
	  static Node *Create(int z){
			int x;
			cout<<"enter the data";
			cin>>x;
			Node *newNode=new Node(x);
			if(x==-1){
				return NULL;
			}
			else
			{
				cout<<"enter the left Child"<<endl;
				newNode->left=Create(z);
				cout<<"enter the right Child"<<endl;
				newNode->right=Create(z);
				return newNode;
			}
		}
	
};
int main(){
	Node *root;
	root=NULL;
	root=Node::Create(3);
	
}