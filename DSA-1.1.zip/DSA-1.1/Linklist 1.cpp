#include<iostream>
using namespace std;
class Node{
	public:
	int data; 
	 Node *next;
	 Node(int data){
		this->data=data;
		this->next=NULL;
	}
};
class Linklist{
	private:
		Node *head;
		public:
			Linklist(){
				head=NULL;
			}
    void Create(int data){
    	Node *newNode=new Node(data);
    	if(head==NULL){
    	head=newNode;
		}
		else
		newNode->next=head;
		head=newNode;
	}
	void Print(){
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<endl;
		temp=temp->next;
	}
	cout<<endl;
}
};
int main(){
	Linklist list;
	list.Create(6);
	list.Create(7);
	list.Create(8);
	list.Print();
}

