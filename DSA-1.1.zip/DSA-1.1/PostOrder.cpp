#include<iostream>
using namespace std;
struct Node{
	public:
		int data;
		Node *left, *right;
	Node(int val){
		data=val;
		left=right=NULL;
	}
};
void PostOrder(Node *root){
	if(root!=NULL){
		PostOrder(root->left);
		PostOrder(root->right);
		cout<<root->data<<endl;
	}
}
int main(){
	Node *root=new Node(4);
	root->left=new Node(1);
	root->right=new Node(5);
	PostOrder(root);
}