#include<iostream>
using namespace std;
class Linklist{
	private:
	  struct Node{
		int data;
		Node *next_add;
	};
	public:
		Node *head;
		Linklist(){
			head=NULL;
		}
		void InsertNode(int);
		void Display();
		void CountList();
		void Display_Sum();
		void Specific_Node(int);
		void SearchNode(int);
		void DeleteNode(int);
};
 void Linklist::InsertNode(int n){
 	        Node *new_Node=new Node();
			new_Node->data=n;
			new_Node->next_add=NULL;
			if(head==NULL){
			  head=new_Node;
			}
			else
			{
				Node *nodeptr;
				nodeptr=head;
				while(nodeptr->next_add!=NULL){
					nodeptr=nodeptr->next_add;
				}
				nodeptr->next_add=new_Node;
			}
		}
		void Linklist::DeleteNode(int z){
					if(head==NULL){
			  cout<<"Empty List";
			}
			else
			{ 
			if(head->data==z){
				Node *nodeptr=head;
				head=head->next_add;
				delete nodeptr;
		}
		else{
		
		      Node *nodeptr=head->next_add;
		      Node *prev=head;
				while(nodeptr!=NULL){
					if(nodeptr->data==z){
					prev->next_add=nodeptr->next_add;
					delete nodeptr;
					break;
					}
					prev=nodeptr;
					nodeptr=nodeptr->next_add; 
				}
		}
	}
}
		void Linklist:: SearchNode(int m){
					int count=0;
				if(head==NULL){
			  cout<<"";
			}
			else
			{
				Node *nodeptr;
				nodeptr=head;
			 bool found=false;
				while(nodeptr!=NULL){
					if(nodeptr->data==m){
						count++;
						found=true;
					}
					nodeptr=nodeptr->next_add; 
				}
				if(found==true){
					cout<<"No found at index"<<count<<endl;
				}
				else{
					cout<<"No Not found"<<endl;
				}
			}
		}
		void Linklist::CountList(){
			int count=0;
				if(head==NULL){
			  cout<<"";
			}
			else
			{
				Node *nodeptr;
				nodeptr=head;
				while(nodeptr!=NULL){
					count++;
					nodeptr=nodeptr->next_add; 
				}
				cout<<"Total No of Node"<<count<<endl;
				nodeptr->next_add=nodeptr;
			}
		}
		void Linklist::Specific_Node(int x){
					if(head==NULL){
			  cout<<"";
			}
			else
			{
				Node *nodeptr;
				nodeptr=head;
				int a=0;
				while(nodeptr!=NULL){
					a++;
					if(a==x){
				cout<<x<<"th term is:"<<nodeptr->data<<endl;
				break;
			}
				nodeptr=nodeptr->next_add;
				}
			}
		}
		void Linklist::Display_Sum(){
				if(head==NULL){
			  cout<<"";
			}
			else
			{
				Node *nodeptr;
				nodeptr=head;
				int sum=0;
				while(nodeptr!=NULL){
				sum=sum+nodeptr->data; 
				nodeptr=nodeptr->next_add;
				}
				cout<<"Total Sum of List"<<sum<<endl;
			}
			}
	void Linklist::Display(){
		Node *new_Node=new Node();
			if(head==NULL){
			  cout<<"empty list"<<endl;
			}
			else
			{
				Node *nodeptr;
				nodeptr=head;
				while(nodeptr!=NULL){
					cout<<nodeptr->data<<endl;
					nodeptr=nodeptr->next_add;
				}
			}
		}	
int main(){
	Linklist l1;
	l1.InsertNode(2);
	l1.InsertNode(4);
	l1.InsertNode(5);
	l1.Display();
	l1.Specific_Node(2);
	l1.Display_Sum();
	l1.DeleteNode(5);
	l1.Display();
	l1.SearchNode(5);
	l1.CountList();
}