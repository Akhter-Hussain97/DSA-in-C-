#include<iostream>
using namespace std;
	class Node{
		public:
			int data;
			Node *left, *right;
			Node(int val){
				data=val;
				left=right=NULL;
			}
	};
class PreInPost{
    public:
    	void PreOrder(Node *root)
    	{
    		if(root==NULL){
    			return ;
			}
			else{
				cout<<root->data<<endl;
    		PreOrder(root->left);
    		PreOrder(root->right);
			}
		}
			void InOrder(Node *root)
    	{
    		if(root==NULL){
    			return ;
			}
			else{
    		InOrder(root->left);
    		cout<<root->data<<endl;
    		InOrder(root->right);
			}
		}
				void PostOrder(Node *root)
    	{
    		if(root==NULL){
    			return ;
			}
			else{
    		PostOrder(root->left);
    		PostOrder(root->right);
    		cout<<root->data<<endl;
			}
		}
};

int main(){
	PreInPost pip;
	 Node *root=new Node(1);
	 root->left=new Node(2);
	 root->right=new Node(3);
	 root->left->left=new Node(8);
	 root->right->right=new Node(19);
	 root->left->left->left=new Node(18);
	cout<<"PreOrder Traversal"<<endl;
	pip.InOrder(root);
	cout<<"InOrder Traversal"<<endl;
	pip.InOrder(root);
	cout<<"PostOrder Traversal"<<endl;
	pip.PostOrder(root);
}