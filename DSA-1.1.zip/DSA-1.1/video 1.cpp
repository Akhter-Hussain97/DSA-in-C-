#include<iostream>
using namespace std;
void print(int arr[],int size){
	for(int i=0; i<size; i++){
		cout<<arr[i]<<endl;
	}
}
void InsertionSort{
	
}
int main(){
	int size=5;
	int element=2,index=0;
	int arr[50]={3,4,6,7,12};
	print(arr,5);
	InsertionSort(arr,5,2,0);
	print(arr,5);
}