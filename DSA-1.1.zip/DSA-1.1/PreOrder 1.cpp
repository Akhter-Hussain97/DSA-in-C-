#include<iostream>
using namespace std;
struct Node{
	public:
	int data;
	Node *left,*right;
	Node(int val){
		data=val;
		left=right=NULL;
	}
};
	void PreOrder(Node *root){
		if(root!=NULL){
		cout<<root->data<<endl;
		PreOrder(root->left);
		PreOrder(root->right);
	}
	}
int main(){
	Node *root=new Node(19);
	root->left=new Node(3);
	root->right=new Node(7);
	root->left->left=new Node(8);
	root->right->right=new Node(10);
	cout<<"PreOrder Traversal"<<endl;
	PreOrder(root);
}