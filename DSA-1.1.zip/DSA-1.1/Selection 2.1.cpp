#include<iostream>
using namespace std;
void SelectionSort(int arr[],int size){
	for(int i=0; i<size-1; i++){
		for(int j=i+1; j<size; j++){
		if(arr[i]>arr[j]){
			int temp; 
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
	}
	}
}
void arrayShows(int arr[], int size){
	  for(int i=0; i<size; i++){
	  	cout<<arr[i]<<endl;
	  }
}
int main(){
	int arr[5],size;
	cout<<"enter the size of the array"<<endl;
	cin>>size;
	for(int i=0; i<size; i++){
		cin>>arr[i];
	}
	cout<<"before array sorting"<<endl;
	arrayShows(arr,size);
	SelectionSort(arr,size);
	cout<<"after array sorting"<<endl;
	arrayShows(arr,size);
}