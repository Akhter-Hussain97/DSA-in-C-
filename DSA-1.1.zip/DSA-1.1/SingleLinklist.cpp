#include<iostream>
using namespace std;
class Node{
	public:
		int data;
		Node *next;
		Node(int data){
		this->data=data;
		this->next=NULL;
		}
};
class SingleLList{
	private:
	Node *head;
	public:
	SingleLList(){
		head=NULL;
	}
	void InsertBegin(int data){
		Node *newNode=new Node(data);
		newNode->data=data;
		newNode->next=NULL;
		if(head==NULL){
		head=newNode;	
		}
		else{
		newNode->next=head;
		head=newNode;
		
	}
}
		void Print(){
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<endl;
		temp=temp->next;
	}
	cout<<endl;
}
};
int main(){
	SingleLList list;
	list.InsertBegin(4);
	list.InsertBegin(5);
	list.InsertBegin(9);
	list.InsertBegin(11);
	list.Print();
}