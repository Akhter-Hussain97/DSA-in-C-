#include<iostream>
using namespace std;
void TowerofHanoi(int n,string src, string helper,string dist){
	if(n==1){
		cout<<"disc is"<<src<<"to"<<helper<<endl;
	}
	TowerofHanoi(n-1,src,dist,helper);
	cout<<"Transfer disc from"<<src<<"to"<<dist<<endl;
	TowerofHanoi(n-1,helper,src,dist);
}
int main(){
	int n;
	cout<<"enter the no of disc"<<endl;
	cin>>n;
	TowerofHanoi(n,"S","H","D");
}