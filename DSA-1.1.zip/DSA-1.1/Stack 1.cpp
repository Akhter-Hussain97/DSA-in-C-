#include<iostream>
using namespace std;
# define n 100
class Stack{
	int* arr;
	int top;
	public:
	Stack(){
		top=-1;
	  arr=new int[n];
}
	void Push(int x){
		if(top==n-1){
			cout<<"Stack Overflow"<<endl;
			return;
		}
		top++;
		arr[top]=x;
	}
	
	void Pop(){
		if(top==-1){
			cout<<"No Element in Pop"<<endl;
			return;
		}
		top--;	
	}
	int Top(){
		if(top==-1){
			cout<<"NO Element in Stack "<<endl;
			return -1;
		}
		return arr[top];
	}
	bool Empty(){
		return top==-1;
	}
};
int main(){
	Stack st;
	st.Push(1);
	st.Push(2);
	st.Push(3);
	cout<<st.Top()<<endl;
	st.Pop();
	cout<<st.Top()<<endl;
	st.Pop();
	st.Pop();
	st.Pop();
	st.Empty();
}