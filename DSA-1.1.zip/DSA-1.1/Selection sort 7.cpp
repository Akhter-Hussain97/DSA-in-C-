#include<iostream>
using namespace std;
int main(){
	int arr[5]={5,4,1,9,0},temp;
	for(int i=0; i<5; i++){
		cout<<arr[i]<<endl;
	}
	for(int i=0; i<5; i++){
		for(int j=i+1; j<5; j++)
			if(arr[i]>arr[j]){
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
			}
	}
	cout<<"after sorting"<<endl;
		for(int i=0; i<5; i++){
		cout<<arr[i]<<endl;
	}
}