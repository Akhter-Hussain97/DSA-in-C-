#include<iostream>
#include<string>
using namespace std;
struct Student{
    int rollNumber;
    string name;
    int Class;
    Student* next;
};

class StudentList{
private:
    Student* head;

public:
    StudentList():head(NULL){}
    void addStudent(int rollNumber,const string& name, int Class){
        Student* newStudent=new Student;
        newStudent->rollNumber=rollNumber;
        newStudent->name=name;
        newStudent->Class=Class;
        newStudent->next=NULL;

        if(head==NULL){
            head=newStudent;
        } else{
            Student* temp=head;
            while(temp->next!=NULL){
                temp=temp->next;
            }
            temp->next=newStudent;
        }

        cout<<"Student record added successfully."<<endl;
    }
    void searchStudent(int rollNumber){
        Student* temp=head;
        while(temp!=NULL){
            if(temp->rollNumber==rollNumber) {
                cout<<"Student found:"<<endl;
                cout<<"Roll Number: "<<temp->rollNumber <<endl;
                cout<<"Name: "<<temp->name <<endl;
                cout<<"Class: "<<temp->Class<<endl;
                return;
            }
            temp=temp->next;
        }

        cout<<"Student with Roll Number "<<rollNumber<<" not found."<<endl;
    }

    void updateStudent(int rollNumber, const string& newName, int newClass) {
        Student* temp=head;
        while(temp!=NULL) {
            if(temp->rollNumber==rollNumber){
                temp->name=newName;
                temp->Class=newClass;
                cout<<"Student record updated successfully."<<endl;
                return;
            }
            temp=temp->next;
        }

        cout<<"Student with Roll Number "<< rollNumber<<"not found."<<endl;
    }

    void deleteStudent(int rollNumber) {
        if(head==NULL){
            cout<<"No student records to delete."<<endl;
            return;
        }

        if(head->rollNumber==rollNumber){
            Student* temp=head;
            head=head->next;
            delete temp;
            cout<<"Student record deleted successfully."<<endl;
            return;
        }

        Student* current=head;
        Student* previous=NULL;

        while(current !=NULL&&current->rollNumber!=rollNumber){
            previous = current;
            current = current->next;
        }

        if (current == nullptr) {
            cout << "Student with Roll Number " << rollNumber << " not found." << endl;
        } else {
            previous->next = current->next;
            delete current;
            cout << "Student record deleted successfully." << endl;
        }
    }

    ~StudentList() {
        Student* temp;
        while (head != nullptr) {
            temp = head;
            head = head->next;
            delete temp;
        }
    }
};
int main() {
    StudentList studentList;

    int choice, rollNumber;
    string name;
    float marks;

    do {
        cout << "\nStudent Information System Menu:" << endl;
        cout << "1. Add Student\n2. Search Student\n3. Update Student\n4. Delete Student\n5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Roll Number: ";
                cin >> rollNumber;
                cout << "Enter Name: ";
                cin.ignore(); // Ignore the newline character left in the buffer
                getline(cin, name);
                cout << "Enter Marks: ";
                cin >> marks;
                studentList.addStudent(rollNumber, name, marks);
                break;

            case 2:
                cout << "Enter Roll Number to search: ";
                cin >> rollNumber;
                studentList.searchStudent(rollNumber);
                break;

            case 3:
                cout << "Enter Roll Number to update: ";
                cin >> rollNumber;
                cout << "Enter New Name: ";
                cin.ignore();
                getline(cin, name);
                cout << "Enter New Marks: ";
                cin >> marks;
                studentList.updateStudent(rollNumber, name, marks);
                break;

            case 4:
                cout << "Enter Roll Number to delete: ";
                cin >> rollNumber;
                studentList.deleteStudent(rollNumber);
                break;

            case 5:
                cout << "Exiting program." << endl;
                break;

            default:
                cout << "Invalid choice. Please enter a valid option." << endl;
        }
    } while (choice != 5);

    return 0;
}
