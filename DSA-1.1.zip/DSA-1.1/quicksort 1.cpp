#include<iostream>
using namespace std;
int partition(int arr[], int low, int high){
	int i=low+1;
	int j=high;
	int pivot=arr[low];
	do{
	while(arr[i]<=pivot){
		i++;
	}
	while(arr[j]>pivot){
		j--;
	}
	while(i<j){
		int temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
	}
}
while(i<j);
	int temp=arr[low];
		arr[low]=arr[j];
		arr[j]=temp;
		return j;
}
void Printarray(int arr[],int size){
	  for(int i=0; i<size; i++){
	  	cout<<arr[i]<<endl;
	  }
}
void quicksort(int arr[], int low, int high){
	int partitionindex;
	if(low<high){
	partitionindex=partition(arr,low,high);
	quicksort(arr,partitionindex-1,low);
	quicksort(arr,partitionindex+1,high);
}
}
int main(){
	int size;
	int low=0,high=size-1;
	cout<<"enter the size of array"<<endl;
	cin>>size;
	int arr[size];
	cout<<"enter the array element"<<endl;
	for(int i=0; i<size; i++){
	cin>>arr[i];
}
     Printarray(arr,size);
     quicksort(arr,0,size-1);
     cout<<"after sorting"<<endl;
     Printarray(arr,size);
}
